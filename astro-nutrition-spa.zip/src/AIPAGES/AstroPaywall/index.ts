export { default } from './AstroPaywall';
