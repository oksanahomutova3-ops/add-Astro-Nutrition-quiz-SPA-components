/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroPaywall.module.scss';

function Page() {
  const { onNext, currentIndex } = useNav();
  const [plan, setPlan] = useState('weekly');

  const plans = [
    { id: 'trial', label: t('astroPaywall.plans.trial'), price: '$1' },
    { id: 'weekly', label: t('astroPaywall.plans.weekly'), price: '$5.49/wk' },
    { id: 'monthly', label: t('astroPaywall.plans.monthly'), price: '$9.99/mo' },
  ];

  const features = [
    { icon: '🍽️', text: t('astroPaywall.features.meals') },
    { icon: '📊', text: t('astroPaywall.features.dashboard') },
    { icon: '🌙', text: t('astroPaywall.features.lunar') },
    { icon: '📱', text: t('astroPaywall.features.updates') },
  ];

  return (
    <div className={styles.page}>
      <div className={styles.section}>
        <p className={styles.title}>{t('astroPaywall.title')}</p>
        <p className={styles.subtitle}>{t('astroPaywall.subtitle')}</p>
      </div>

      <div className={styles.plans}>
        {plans.map((p) => (
          <div
            key={p.id}
            className={`${styles.plan} ${plan === p.id ? styles.selected : ''}`}
            onClick={() => setPlan(p.id)}
          >
            <span className={styles.planLabel}>{p.label}</span>
            <span className={styles.planPrice}>{p.price}</span>
          </div>
        ))}
      </div>

      <div className={styles.section}>
        <p className={styles.title}>{t('astroPaywall.whatsInside')}</p>
        <div className={styles.featureList}>
          {features.map((f, i) => (
            <div key={i} className={styles.featureItem}>
              <span className={styles.featureIcon}>{f.icon}</span>
              <span>{f.text}</span>
            </div>
          ))}
        </div>
      </div>

      <p className={styles.guarantee}>{t('astroPaywall.guarantee')}</p>

      <div className={styles.btnWrap}>
        <Button
          onClick={() => {
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'astroPaywall',
              plan,
            });
            onNext();
          }}
        >
          {t('astroPaywall.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
