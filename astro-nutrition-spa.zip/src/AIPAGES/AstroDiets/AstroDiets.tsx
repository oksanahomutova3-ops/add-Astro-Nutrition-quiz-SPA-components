/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { Check } from '../../components/ui/check/Check';
import { Option } from '../../components/ui/check/Option';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import styles from './AstroDiets.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroDiets.title')}</p>
        <p className={styles.description}>{t('astroDiets.subtitle')}</p>
      </div>
      <div className={styles.controls}>
        <Check
          defaultValue={answer}
          onChange={(value) => {
            setAnswer(value);
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'astroDiets',
              answer: value,
            });
            onNext();
          }}
        >
          <Option value="none">
            <span>🍽️</span> {t('astroDiets.options.none')}
          </Option>
          <Option value="few">
            <span>📋</span> {t('astroDiets.options.few')}
          </Option>
          <Option value="many">
            <span>📚</span> {t('astroDiets.options.many')}
          </Option>
          <Option value="always">
            <span>🔄</span> {t('astroDiets.options.always')}
          </Option>
        </Check>
      </div>
    </div>
  );
}

export default Page;
