export { default } from './AstroDiets';
