export { default } from './AstroBirthtime';
