/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroBirthtime.module.scss';

function Page() {
  const { onNext, onPrev, currentIndex } = useNav();
  const setAnswer = useStore((state) => state.setAnswer);
  const [hour, setHour] = useState(12);
  const [minute, setMinute] = useState(0);
  const [ampm, setAmpm] = useState('AM');

  const handleContinue = () => {
    setAnswer({ hour, minute, ampm });
    Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
      page: 'astroBirthtime',
      answer: `${hour}:${String(minute).padStart(2, '0')} ${ampm}`,
    });
    onNext();
  };

  const handleSkip = () => {
    setAnswer({ hour: null, minute: null, ampm: null });
    Analytics.trackEvent(`step${currentIndex + 1}`, 'skip', { page: 'astroBirthtime' });
    onNext();
  };

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroBirthtime.title')}</p>
        <p className={styles.description}>{t('astroBirthtime.subtitle')}</p>
      </div>
      <div className={styles.pickerWrap}>
        <select value={hour} onChange={(e) => setHour(Number(e.target.value))}>
          {Array.from({ length: 12 }, (_, i) => (
            <option key={i + 1} value={i + 1}>{i + 1}</option>
          ))}
        </select>
        <select value={minute} onChange={(e) => setMinute(Number(e.target.value))}>
          {Array.from({ length: 60 }, (_, i) => (
            <option key={i} value={i}>{String(i).padStart(2, '0')}</option>
          ))}
        </select>
        <select value={ampm} onChange={(e) => setAmpm(e.target.value)}>
          <option value="AM">AM</option>
          <option value="PM">PM</option>
        </select>
      </div>
      <div className={styles.btnWrap}>
        <Button onClick={handleContinue}>{t('astroBirthtime.cta')}</Button>
      </div>
      <div className={styles.skipLink} onClick={handleSkip}>
        {t('astroBirthtime.skip')}
      </div>
    </div>
  );
}

export default Page;
