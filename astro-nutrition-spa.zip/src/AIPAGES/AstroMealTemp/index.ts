export { default } from './AstroMealTemp';
