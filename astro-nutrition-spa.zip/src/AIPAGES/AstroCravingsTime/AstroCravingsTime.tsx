/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { Check } from '../../components/ui/check/Check';
import { Option } from '../../components/ui/check/Option';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import styles from './AstroCravingsTime.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroCravingsTime.title')}</p>
        <p className={styles.description}>{t('astroCravingsTime.subtitle')}</p>
      </div>
      <div className={styles.controls}>
        <Check
          defaultValue={answer}
          onChange={(value) => {
            setAnswer(value);
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'astroCravingsTime',
              answer: value,
            });
            onNext();
          }}
        >
          <Option value="morning">
            <span>🌅</span> {t('astroCravingsTime.options.morning')}
          </Option>
          <Option value="afternoon">
            <span>☀️</span> {t('astroCravingsTime.options.afternoon')}
          </Option>
          <Option value="evening">
            <span>🌙</span> {t('astroCravingsTime.options.evening')}
          </Option>
          <Option value="lateNight">
            <span>🌑</span> {t('astroCravingsTime.options.lateNight')}
          </Option>
        </Check>
      </div>
    </div>
  );
}

export default Page;
