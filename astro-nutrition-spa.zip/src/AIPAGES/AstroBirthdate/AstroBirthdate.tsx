/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroBirthdate.module.scss';

function Page() {
  const { onNext, onPrev, currentIndex } = useNav();
  const setAnswer = useStore((state) => state.setAnswer);
  const [day, setDay] = useState(15);
  const [month, setMonth] = useState(6);
  const [year, setYear] = useState(1995);

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroBirthdate.title')}</p>
        <p className={styles.description}>{t('astroBirthdate.subtitle')}</p>
      </div>
      <div className={styles.pickerWrap}>
        <select value={day} onChange={(e) => setDay(Number(e.target.value))}>
          {Array.from({ length: 31 }, (_, i) => (
            <option key={i + 1} value={i + 1}>{i + 1}</option>
          ))}
        </select>
        <select value={month} onChange={(e) => setMonth(Number(e.target.value))}>
          {Array.from({ length: 12 }, (_, i) => (
            <option key={i + 1} value={i + 1}>{i + 1}</option>
          ))}
        </select>
        <select value={year} onChange={(e) => setYear(Number(e.target.value))}>
          {Array.from({ length: 80 }, (_, i) => {
            const y = 2007 - i;
            return <option key={y} value={y}>{y}</option>;
          })}
        </select>
      </div>
      <div className={styles.btnWrap}>
        <Button
          onClick={() => {
            setAnswer({ day, month, year });
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'astroBirthdate',
              answer: `${year}-${month}-${day}`,
            });
            onNext();
          }}
        >
          {t('astroBirthdate.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
