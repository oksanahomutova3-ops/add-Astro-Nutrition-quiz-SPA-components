export { default } from './AstroBirthdate';
