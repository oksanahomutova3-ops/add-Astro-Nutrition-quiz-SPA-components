export { default } from './AstroRestrictions';
