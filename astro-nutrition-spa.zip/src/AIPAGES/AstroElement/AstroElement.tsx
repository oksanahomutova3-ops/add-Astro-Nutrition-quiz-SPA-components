/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroElement.module.scss';

function Page() {
  const { onNext, onPrev, currentIndex } = useNav();
  const zodiac = useStore((state) => state.zodiac);

  const sign = zodiac?.sign || 'Aries';
  const emoji = zodiac?.emoji || '♈';

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.content}>
        <div className={styles.pill}>
          <span>{emoji}</span>
          <span>{sign}</span>
        </div>
        <p className={styles.title}>{t(`astroElement.title_${zodiac?.element || 'Fire'}`)}</p>
        <p className={styles.text}>{t(`astroElement.text_${zodiac?.element || 'Fire'}`)}</p>
      </div>
      <div className={styles.btnWrap}>
        <Button
          onClick={() => {
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', { page: 'astroElement' });
            onNext();
          }}
        >
          {t('astroElement.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
