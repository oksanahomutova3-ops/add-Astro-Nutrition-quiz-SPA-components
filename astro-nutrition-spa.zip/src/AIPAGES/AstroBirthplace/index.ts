export { default } from './AstroBirthplace';
