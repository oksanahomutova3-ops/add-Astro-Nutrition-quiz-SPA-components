/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import styles from './AstroBirthplace.module.scss';

const POPULAR_CITIES = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'London',
  'Toronto', 'Sydney', 'Berlin', 'Paris', 'Tokyo',
  'Mumbai', 'São Paulo', 'Mexico City', 'Seoul', 'Dubai',
];

function Page() {
  const { onNext, onPrev, currentIndex } = useNav();
  const setAnswer = useStore((state) => state.setAnswer);
  const [query, setQuery] = useState('');

  const filtered = query.length > 0
    ? POPULAR_CITIES.filter((c) => c.toLowerCase().includes(query.toLowerCase())).slice(0, 5)
    : [];

  const handleSelect = (city: string) => {
    setAnswer(city);
    Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
      page: 'astroBirthplace',
      answer: city,
    });
    onNext();
  };

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroBirthplace.title')}</p>
        <p className={styles.description}>{t('astroBirthplace.subtitle')}</p>
      </div>
      <div className={styles.inputWrap}>
        <input
          className={styles.input}
          placeholder={t('astroBirthplace.placeholder')}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className={styles.suggestions}>
          {filtered.map((city) => (
            <button
              key={city}
              className={styles.suggestionItem}
              onClick={() => handleSelect(city)}
            >
              {city}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Page;
