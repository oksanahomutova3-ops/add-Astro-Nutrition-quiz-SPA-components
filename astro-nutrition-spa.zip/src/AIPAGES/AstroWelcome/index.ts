export { default } from './AstroWelcome';
