/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroCoordinates.module.scss';

function Page() {
  const { onNext, onPrev, currentIndex } = useNav();

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.content}>
        <p className={styles.title}>{t('astroCoordinates.title')}</p>
        <p className={styles.coords}>40.7128° N, 74.0060° W</p>
        <p className={styles.text}>{t('astroCoordinates.text')}</p>
      </div>
      <div className={styles.btnWrap}>
        <Button
          onClick={() => {
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', { page: 'astroCoordinates' });
            onNext();
          }}
        >
          {t('astroCoordinates.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
