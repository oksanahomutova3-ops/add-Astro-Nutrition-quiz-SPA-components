export { default } from './AstroCoordinates';
