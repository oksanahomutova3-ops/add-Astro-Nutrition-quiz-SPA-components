/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { t } from '@web-solutions/module-localization';
import { useNav } from '../../hooks/nav';
import styles from './AstroScan.module.scss';

function Page() {
  const { onNext } = useNav();
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const delays = [1000, 2200, 3400, 4600, 5800, 7000, 7800];
    const timers = delays.map((delay, i) =>
      setTimeout(() => setPhase(i + 1), delay)
    );
    const navTimer = setTimeout(() => onNext(), 8500);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(navTimer);
    };
  }, [onNext]);

  const phases = [
    t('astroScan.phases.chart'),
    t('astroScan.phases.element'),
    t('astroScan.phases.metabolism'),
    t('astroScan.phases.cravings'),
    t('astroScan.phases.nutrients'),
    t('astroScan.phases.schedule'),
    t('astroScan.phases.plan'),
  ];

  const totalPhases = phases.length;
  const pct = Math.round((phase / totalPhases) * 100);
  const circumference = 2 * Math.PI * 65;

  return (
    <div className={styles.page}>
      <div className={styles.ring}>
        <svg viewBox="0 0 150 150" className={styles.svg}>
          <circle cx="75" cy="75" r="65" fill="none" stroke="#f2f3f5" strokeWidth="8" />
          <circle
            cx="75" cy="75" r="65" fill="none" stroke="#00ce00" strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - circumference * (pct / 100)}
            strokeLinecap="round"
            className={styles.progress}
          />
        </svg>
        <span className={styles.pct}>{pct}%</span>
      </div>
      <div className={styles.phases}>
        {phases.map((p, i) => (
          <div key={i} className={`${styles.phaseItem} ${i < phase ? styles.done : ''}`}>
            <span className={styles.icon}>{i < phase ? '✓' : '○'}</span>
            <span>{p}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Page;
