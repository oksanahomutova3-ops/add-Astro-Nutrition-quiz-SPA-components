export { default } from './AstroGoal';
