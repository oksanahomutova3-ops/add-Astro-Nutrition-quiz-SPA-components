/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { MultiCheck } from '../../components/ui/multi-check/MultiCheck';
import { MultiOption } from '../../components/ui/multi-check/Option';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './AstroGoal.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();

  const selected: string[] = Array.isArray(answer) ? answer : [];

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('astroGoal.title')}</p>
        <p className={styles.description}>{t('astroGoal.subtitle')}</p>
      </div>
      <div className={styles.controls}>
        <MultiCheck value={selected} onChange={(val) => setAnswer(val)}>
          <MultiOption value="weight">⚖️ {t('astroGoal.options.weight')}</MultiOption>
          <MultiOption value="energy">⚡ {t('astroGoal.options.energy')}</MultiOption>
          <MultiOption value="digestion">🫄 {t('astroGoal.options.digestion')}</MultiOption>
          <MultiOption value="skin">✨ {t('astroGoal.options.skin')}</MultiOption>
          <MultiOption value="cravings">🍫 {t('astroGoal.options.cravings')}</MultiOption>
          <MultiOption value="understand">🧠 {t('astroGoal.options.understand')}</MultiOption>
        </MultiCheck>
      </div>
      <div className={styles.btnWrap}>
        <Button
          disabled={selected.length === 0}
          onClick={() => {
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'astroGoal',
              answer: selected.join(','),
            });
            onNext();
          }}
        >
          {t('astroGoal.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
